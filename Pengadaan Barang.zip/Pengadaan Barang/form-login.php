<?php
session_start();
include 'koneksi.php';
// echo md5('z');
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $hasil =    mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username = '$username' AND password = '$password'");
    // cek username dan password
    if (mysqli_num_rows($hasil) > 0) {

        //cek password
        $row = mysqli_fetch_assoc($hasil);
        if ($password == $row['password']) {
            $_SESSION['username'] = $username;
            var_dump($_SESSION);
            header("Location: dashboard.php");
        }
    }
    $error = true;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PT . Pandega</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous" />
    <link rel="stylesheet" type="text/css" href="css/login.css" />
</head>

<body>
    <!-- Header-->
    <div class="container">
        <h4 class="text-center">Silahkan Login</h4>
        <hr />
        <?php if (isset($error)) : ?>
            <div class="alert alert-danger" role="alert">
                Username dan Password anda salah !
            </div>
        <?php endif; ?>

        <!-- Membuat Form Login-->
        <form action="form-login.php" method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" required name="username" class="form-control" placeholder="masukan username" autocomplete="off" />
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" required name="password" class="form-control" placeholder="masukan password" />
            </div>
            <button type="submit" class="btn btn-primary" name="login">Submit</button>
            <button type="reset" class="btn btn-danger" name="reset">Reset</button>
            <br>
            <br>
            <div class="alert alert-primary" role="alert">
                Pastikan Username dan Password anda benar !
            </div>
        </form>
    </div>
</body>

</html>
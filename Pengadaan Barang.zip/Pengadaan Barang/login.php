<?php
session_start();
include 'koneksi.php';

//tangkap data dari form
$username = $_POST['username'];
$password = md5($_POST['password']);

//mulai query
$query = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username = '$username' AND password = '$password'");
$cek = mysqli_num_rows($query);

//cek kondisi
if ($cek) {
    $_SESSION['username'] = $username;
?>Anda Berhasil Login , Silahkan menuju <a href="dashboard.php">Halaman Dashboard</a>

<?php
} else {
?>Anda gagal login, silahkan <a href="form.html">Login Kembali</a>
<?php
    // echo mysqli_error();
}
?>